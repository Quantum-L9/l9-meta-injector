# L9 Repository Preflight — Audit Findings (static-only)

- **Repository:** `quantum-l9/l9-meta-injector`
- **Mode:** filesystem evidence, `--audit-mode static_only` (deterministic Gate 20A; **no reasoning/contract handoff generated**)
- **Skill version:** 4.2  |  **audit_depth:** deterministic
- **Overall status:** `blocker`  (deterministic_status: `blocker`, final: `blocker`)
- **Reasoning assessment:** not_observed (not requested in static-only)
- **Full preflight:** False  |  **Convergence:** converged

**14 findings** — by status: blocker=1, not_observed=3, warning=10 | by severity: low=5, medium=9

## All findings

| ID | Gate | Status | Severity | Evidence | Claim | Recommended change |
|---|---|---|---|---|---|---|
| G16-HEALTH | 16 service-reliability | blocker | medium | observed | declared service lacks a discoverable health endpoint | add a real health/readiness endpoint with dependency checks |
| G15-DEP-RANGE | 15 security-supply-chain | warning | low | observed | dependency constraints permit version drift | review compatibility ranges and pin high-risk build/runtime dependencies |
| G16-ENV | 16 service-reliability | warning | medium | observed | service lacks an environment contract example | add a secret-free environment example |
| G19-VERSION-1 | 19 prompt-tool-contracts | warning | low | observed | prompt lacks a version marker | add a version marker |
| G20-SYNTHESIS | 20 forensic-synthesis | warning | medium | observed | cross-gate synthesis found material unresolved evidence | resolve the originating gate findings |
| SEM-ACT-1 | 14 ci-integrity | warning | medium | - | mutable GitHub Action reference detected | pin_static_github_action |
| SEM-ACT-2 | 14 ci-integrity | warning | medium | - | mutable GitHub Action reference detected | pin_static_github_action |
| SEM-ACT-3 | 14 ci-integrity | warning | medium | - | mutable GitHub Action reference detected | pin_static_github_action |
| SEM-ACT-4 | 14 ci-integrity | warning | medium | - | mutable GitHub Action reference detected | pin_static_github_action |
| SEM-ACT-5 | 14 ci-integrity | warning | medium | - | mutable GitHub Action reference detected | pin_static_github_action |
| SEM-ACT-6 | 14 ci-integrity | warning | medium | - | mutable GitHub Action reference detected | pin_static_github_action |
| G18-import-linter | 18 quality-maintainability | not_observed | low | not_observed | import-linter analysis was not observed | provide import-linter when this evidence is required |
| G18-jscpd | 18 quality-maintainability | not_observed | low | not_observed | jscpd analysis was not observed | provide jscpd when this evidence is required |
| G18-radon | 18 quality-maintainability | not_observed | low | not_observed | radon analysis was not observed | provide radon when this evidence is required |

## Gate coverage

| Gate | Name | Status | Applicable |
|---|---|---|---|
| U01 | repository-readable | clear |  |
| U02 | declared-purpose-identifiable | clear |  |
| U03 | secrets-absent | clear |  |
| U04 | manifest-integrity | clear |  |
| U05 | generated-artifact-integrity | clear |  |
| U06 | documentation-alignment | clear |  |
| U07 | ci-truthfulness | clear |  |
| U08 | dependency-reference-immutability | warning |  |
| U09 | merge-debris-absent | clear |  |
| U10 | evidence-completeness | clear |  |
| A-PY-01 | python-packaging-metadata | not_applicable |  |
| A-WF-01 | reusable-workflow-contract | not_applicable |  |
| 15 | security-supply-chain | warning | True |
| 16 | service-reliability | blocker | True |
| 17 | data-safety | clear | True |
| 18 | quality-maintainability | not_observed | True |
| 19 | prompt-tool-contracts | warning | True |
| 20 | forensic-synthesis | warning | True |

## Limitations / not observed

- gate20_reasoning_not_executed
- repository_intelligence_coverage_incomplete
- semantic_index_partial_parse

Evidence completeness: `warning` | incomplete gates: [18] | parser limitations: ['semantic_index_partial_parse']

## Files in this package

- `AUDIT_FINDINGS.md` — this report
- `findings.json` — all findings, machine-readable
- `findings.csv` — all findings, spreadsheet-friendly
- `preflight-report.json` — full canonical report
- `environment-capability-report.json` — host/environment capability detection
- `preflight/gate20-static.json` — Gate 20A deterministic synthesis
- `preflight/gate20-forensic-audit.json` — full Gate 20 forensic audit (static-only; reasoning=not_observed)
- `preflight/semantic-snapshot.json`, `semantic-resolution-graph.json`, `semantic-coverage.json`, `semantic-delta.json`, `semantic-evidence.jsonl` — repository intelligence artifacts

> Note: no `gate20-reasoning-request.json` / `gate20-reasoning-response.json` were produced — static-only mode emits no host-agent reasoning contract.

> Caveat: the installed skill still contains the known Gate 20 `deterministic_summary` double-count (see prior bug report); it affects only `gate20-static.json`/`forensic_audit.static` internals, not the finding list above.
