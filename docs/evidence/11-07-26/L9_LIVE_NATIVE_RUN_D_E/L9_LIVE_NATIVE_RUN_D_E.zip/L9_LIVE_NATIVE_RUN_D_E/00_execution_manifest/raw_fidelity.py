#!/usr/bin/python3
from pathlib import Path
import json,sys,collections,hashlib
base=Path(sys.argv[1]);packet=json.loads((base/'repository-model/packet.json').read_text());ledger=json.loads((base/'source-inventory/header-declaration-ledger.json').read_text());source=Path(json.loads((base/'source-inventory/source-files.json').read_text())['source_root']);by=collections.defaultdict(list)
for a in packet['payload']['assertions']:
    if a['extractor_id']=='native-metadata/v1':by[a['source_path']].append(a)
rows=[];errors=[]
for f in ledger:
    aa=[a for a in by[f['source_path']] if a['predicate'] not in ['meta.declaration.carrier','meta.declaration.schema'] and f['start_line']<=a['source_range']['start_line']<=a['source_range']['end_line']<=f['end_line']]
    dd=[d for d in packet['payload']['diagnostics'] if d.get('details',{}).get('source_path')==f['source_path']]
    rows.append({**f,'rmp_assertions':aa,'path_diagnostics':dd,'accounting':'assertion' if aa else 'diagnostic' if dd else 'unmatched'})
for aa in by.values():
    for a in aa:
        raw=(source/a['source_path']).read_bytes()
        if 'sha256:'+hashlib.sha256(raw).hexdigest()!=a['source_content_hash']:errors.append({'assertion_id':a['assertion_id'],'reason':'source hash mismatch'})
        if not 1<=a['source_range']['start_line']<=a['source_range']['end_line']<=len(raw.splitlines()):errors.append({'assertion_id':a['assertion_id'],'reason':'source coordinates invalid'})
result={'basis':'Mechanical source-path/line-span joins of existing native parser output and original RMP. No semantic conclusion.','counts':dict(collections.Counter(x['accounting'] for x in rows)),'source_evidence_errors':errors,'rows':rows}
(base/'source-inventory/declaration-to-assertion-fidelity.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'counts':result['counts'],'source_evidence_error_count':len(errors)}))
