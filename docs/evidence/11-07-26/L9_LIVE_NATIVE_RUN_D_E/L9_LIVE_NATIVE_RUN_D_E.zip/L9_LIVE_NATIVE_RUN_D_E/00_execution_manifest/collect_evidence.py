#!/usr/bin/python3
from pathlib import Path
import json,hashlib,shutil,subprocess,collections,sys
ROOT=Path('/home/ubuntu/output/L9_LIVE_NATIVE_RUN_D_E');WORK=Path('/home/ubuntu/live-native-workspace')
load=lambda p:json.loads(p.read_text())
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
integ=ROOT/'05_integrity'
for folder in ['native-validation-receipts','determinism-receipts','source-fidelity','artifact-hashes']:(integ/folder).mkdir(parents=True,exist_ok=True)
results={};bundlechecks=[]
for label,name in [('D','01_ops_control'),('E0','02_cognitive_before'),('E1','04_cognitive_after')]:
    base=ROOT/name;logs=base/'receipts-and-logs';pack=load(base/'repository-model/packet.json');top=load(base/'topology/packet.json')
    for kind,folder in [('repository-model',base/'repository-model'),('topology',base/'topology')]:
        manifest=load(folder/'manifest.json');actual=[]
        for f in manifest['files']:
            p=folder/f['path'];ok=p.stat().st_size==f['size_bytes'] and 'sha256:'+H(p)==f['content_hash'];actual.append({'path':f['path'],'sha256':H(p),'size_bytes':p.stat().st_size,'native_manifest_equal':ok});assert ok
        bundlechecks.append({'run':label,'bundle':kind,'files':actual})
        receipt=folder/'receipts/validation-receipt.json';shutil.copy2(receipt,integ/'native-validation-receipts'/f'{label}-{kind}-validation-receipt.json')
    before=load(base/'source-inventory/source-files.json');after=load(base/'source-inventory-after/source-files.json');assert before==after
    shutil.copy2(base/'source-inventory/declaration-to-assertion-fidelity.json',integ/'source-fidelity'/f'{label}-declaration-to-assertion-fidelity.json')
    shutil.copy2(logs/'determinism.stdout.log',integ/'determinism-receipts'/f'{label}-determinism.json')
    querychecks={}
    for prefix in ['all-claims','managed-predicates']:
        pages=sorted((base/'query-outputs').glob(prefix+'.page-*.stdout.log'));records=[load(p)['result'] for p in pages]
        total=records[0]['total_matched'];returned=sum(p['returned'] for p in records);assert returned==total,(label,prefix,returned,total);assert records[-1]['next_after'] is None
        querychecks[prefix]={'page_count':len(pages),'returned':returned,'native_total_matched':total,'all_pages_preserved':True}
    statuses={p.name.replace('.exit-code.txt',''):int(p.read_text()) for folder in [logs,base/'query-outputs',base/'impact-outputs'] for p in folder.glob('*.exit-code.txt')}
    results[label]={'evidence_directory':name,'source_revision':before['sha'],'rmp_packet_id':pack['packet_id'],'rmp_semantic_hash':pack['semantic_hash'],'topology_packet_id':top['packet_id'],'topology_semantic_hash':top['semantic_hash'],'policy_hashes':top['policy_hashes'],'native_exit_statuses':statuses,'native_producer_receipt_status':load(base/'repository-model/receipts/validation-receipt.json')['status'],'native_topology_receipt_status':load(base/'topology/receipts/validation-receipt.json')['status'],'native_determinism':load(logs/'determinism.stdout.log'),'query_pages':querychecks,'tracked_source_unchanged_during_observation':True}
for repo in ['l9-meta-injector','l9-constellation-topology','L9-Ops-MCP']:
    initial=load(ROOT/'00_execution_manifest'/f'{repo}-initial-inventory/source-files.json')
    for f in initial['files']:assert H(WORK/repo/f['path'])==f['sha256']
    assert subprocess.check_output(['git','-C',str(WORK/repo),'status','--porcelain'])==b''
source=WORK/'l9-cognitive-runtime';commit=load(ROOT/'03_header_injection/git-commit.json');assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD']).decode().strip()==commit['sha'];assert subprocess.check_output(['git','-C',str(source),'status','--porcelain'])==b''
# Native installed consumer code must be byte-identical to the locked checked-out source.
import l9_constellation_topology
installed=Path(l9_constellation_topology.__file__).parent;code=[]
for p in (WORK/'l9-constellation-topology/src/l9_constellation_topology').rglob('*.py'):
    rel=p.relative_to(WORK/'l9-constellation-topology/src/l9_constellation_topology');q=installed/rel;assert q.exists() and H(q)==H(p);code.append({'path':str(rel),'source_sha256':H(p),'installed_path':str(q)})
(integ/'artifact-hashes/native-consumer-code.json').write_text(json.dumps(code,indent=2)+'\n')
(integ/'artifact-hashes/native-bundle-hashes.json').write_text(json.dumps(bundlechecks,indent=2)+'\n')
(ROOT/'00_execution_manifest/run-receipt.json').write_text(json.dumps({'runs':results,'injection':commit,'pr':load(ROOT/'03_header_injection/github-pr.json')['url'],'source_changes':'197 source header files plus two metadata support files on Cognitive Runtime feature branch only','publication':False,'pr_merge':False,'no_containers_or_virtual_environments':True},indent=2)+'\n')
ledger=[json.loads(x) for x in (ROOT/'00_execution_manifest/command-ledger.jsonl').read_text().splitlines()]
(ROOT/'00_execution_manifest/command-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
(integ/'source-fidelity/source-boundaries.json').write_text(json.dumps({'producer_unchanged':True,'consumer_unchanged':True,'ops_control_unchanged':True,'E0_unchanged_during_observation':True,'E1_unchanged_during_observation':True,'cognitive_final_commit':commit['sha'],'cognitive_post_E1_git_status':'','further_source_edits_after_E1':False,'full_native_injection_patch':'03_header_injection/git-diff.patch'},indent=2)+'\n')
print('Native receipt capture, query pagination, source boundaries, and artifact hashes recorded. No analysis.')
