const fs=require('node:fs'),cp=require('node:child_process'),path=require('node:path'),crypto=require('node:crypto');
// Executes the checked-out producer's existing pure native reader; no parser replacement or source edit.
const {parseNativeMetadata}=require('/home/ubuntu/live-native-workspace/l9-meta-injector/dist/native_metadata.js');
const source=process.argv[2],out=process.argv[3];fs.mkdirSync(out,{recursive:true});
const paths=cp.execFileSync('git',['-C',source,'ls-files','-z']).toString().split('\0').filter(Boolean);
const observations=[],exclusions=[];
for(const rel of paths){const file=path.join(source,rel);if(fs.lstatSync(file).isSymbolicLink()){exclusions.push({path:rel,reason:'symlink'});continue;}
if(/(^|\/)(\.env(?!\.example$)[^/]*|[^/]*\.(pem|key|p12|pfx))$/.test(rel)){exclusions.push({path:rel,reason:'secret path: content not read'});continue;}
const raw=fs.readFileSync(file);if(raw.includes(0)){exclusions.push({path:rel,reason:'binary'});continue;}
const parsed=parseNativeMetadata(rel,raw.toString('utf8'));
if(parsed.declarations.length||parsed.regions.length||parsed.diagnostics.length)observations.push({source_path:rel,source_content_hash:'sha256:'+crypto.createHash('sha256').update(raw).digest('hex'),...parsed});}
const declarations=observations.flatMap(o=>o.declarations.flatMap(d=>d.fields.map(f=>({source_path:o.source_path,source_content_hash:o.source_content_hash,carrier:d.carrier,declared_schema:d.declared_schema,header_span:d.source_span,...f}))));
fs.writeFileSync(path.join(out,'native-header-observations.json'),JSON.stringify({producer_revision:'f134e8d54dea51e94f94e6c4afb820931dbc9775',observations,exclusions},null,2)+'\n');
fs.writeFileSync(path.join(out,'header-declaration-ledger.json'),JSON.stringify(declarations,null,2)+'\n');
console.log(JSON.stringify({header_paths:observations.length,declaration_fields:declarations.length,exclusions:exclusions.length}));
