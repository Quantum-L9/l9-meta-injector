#!/usr/bin/python3
from pathlib import Path
import sys,json
from run_native import run,ROOT,CONSUMER,TOPOLOGY
for observation in sys.argv[1:]:
    base=ROOT/observation
    for label,prefix in [('all-claims',None),('managed-predicates','meta.managed.')]:
        folder=base/'query-outputs';first=folder/(label+'.page-0000.stdout.log')
        if not first.exists():continue
        previous=json.loads(first.read_text());after=previous.get('result',previous).get('next_after');page=1
        while after:
            output=folder/(label+f'.page-{page:04d}.stdout.log')
            if output.exists():result=json.loads(output.read_text())
            else:
                args=[TOPOLOGY,'query-claims','--input-bundle',base/'topology','--limit','1000','--after',after]
                if prefix:args+=['--predicate-prefix',prefix]
                rc,output=run(label+f'.page-{page:04d}',args,CONSUMER,folder)
                if rc:break
                result=json.loads(output.read_text())
            after=result.get('result',result).get('next_after');page+=1
