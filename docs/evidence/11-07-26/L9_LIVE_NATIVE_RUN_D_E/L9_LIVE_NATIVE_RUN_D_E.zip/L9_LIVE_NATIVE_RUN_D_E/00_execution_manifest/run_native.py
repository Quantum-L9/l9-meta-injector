#!/usr/bin/python3
from pathlib import Path
import subprocess, json, os, sys, datetime, hashlib, platform, shutil, importlib.metadata
ROOT = Path('/home/ubuntu/output/L9_LIVE_NATIVE_RUN_D_E')
WORK = Path('/home/ubuntu/live-native-workspace')
PRODUCER = WORK / 'l9-meta-injector'
CONSUMER = WORK / 'l9-constellation-topology'
TOPOLOGY = str(Path.home() / '.local/bin/l9-topology')
NODE = shutil.which('node')
ENV = dict(os.environ)
for key in ['VIRTUAL_ENV', 'CONDA_PREFIX', 'UV_PROJECT_ENVIRONMENT', 'PYTHONPATH']:
    ENV.pop(key, None)
ENV['PYTHONDONTWRITEBYTECODE'] = '1'
ENV['PATH'] = str(Path.home() / '.local/bin') + ':' + ENV['PATH']
LEDGER = ROOT / '00_execution_manifest/command-ledger.jsonl'
def run(label, args, cwd, folder):
    folder = Path(folder); folder.mkdir(parents=True, exist_ok=True)
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    command = {'name': label, 'argv': list(map(str,args)), 'cwd': str(cwd), 'started_at': start,
               'stdout': str(folder / (label + '.stdout.log')), 'stderr': str(folder / (label + '.stderr.log'))}
    (folder / (label + '.command.json')).write_text(json.dumps(command,indent=2)+'\n')
    with open(command['stdout'],'wb') as out, open(command['stderr'],'wb') as err:
        p = subprocess.run(command['argv'],cwd=cwd,env=ENV,stdout=out,stderr=err)
    command.update(exit_code=p.returncode,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    (folder / (label+'.exit-code.txt')).write_text(str(p.returncode)+'\n')
    with LEDGER.open('a') as f: f.write(json.dumps(command)+'\n')
    print(label, 'exit', p.returncode, flush=True)
    return p.returncode, folder / (label+'.stdout.log')
def snapshot(source, out):
    out = Path(out); out.mkdir(parents=True,exist_ok=True)
    raw = subprocess.check_output(['git','-C',str(source),'ls-files','-z'])
    files=[]
    for b in raw.split(b'\0'):
        if not b: continue
        rel=os.fsdecode(b); path=source/rel
        if path.is_symlink(): data=os.fsencode(os.readlink(path)); typ='symlink'
        else: data=path.read_bytes(); typ='file'
        files.append({'path':rel,'kind':typ,'size_bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'mode':oct(path.lstat().st_mode & 0o777)})
    state={'source_root':str(source),'sha':subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD']).decode().strip(),'git_status':subprocess.check_output(['git','-C',str(source),'status','--porcelain']).decode(),'files':files}
    (out/'source-files.json').write_text(json.dumps(state,indent=2)+'\n')
    return state

def observation(kind, source):
    name={'D':'01_ops_control','E0':'02_cognitive_before','E1':'04_cognitive_after'}[kind]
    base=ROOT/name; logs=base/'receipts-and-logs'
    for f in ['source-inventory','query-outputs','impact-outputs']: (base/f).mkdir(parents=True,exist_ok=True)
    state=snapshot(source,base/'source-inventory'); assert not state['git_status'],state['git_status']
    run('native-header-inventory',[NODE,ROOT/'00_execution_manifest/native_headers.cjs',source,base/'source-inventory'],PRODUCER,logs)
    rc,_=run('producer',[NODE,PRODUCER/'scripts/repository-model-cli.js',source,'--name',source.name,'--revision','git:'+state['sha'],'--out',base/'repository-model'],PRODUCER,logs)
    if rc: return
    rc,_=run('compile',[TOPOLOGY,'compile-packet','--repo-root',CONSUMER,'--input-bundle',base/'repository-model','--out',base/'topology'],CONSUMER,logs)
    if rc: return
    for label,args in [
        ('validate',['validate-packet','--input-bundle',base/'topology']),
        ('inspect',['inspect-packet','--input-bundle',base/'topology']),
        ('input-bound-revalidate',['validate-packet','--repo-root',CONSUMER,'--input-bundle',base/'topology','--repository-bundle',base/'repository-model']),
        ('determinism',['verify-determinism','--repo-root',CONSUMER,'--input-bundle',base/'repository-model'])]:
        run(label,[TOPOLOGY,*args],CONSUMER,logs)
    # Use the same filters/configuration on each observation. Pagination preserves all native pages.
    for label,prefix in [('all-claims',None),('managed-predicates','meta.managed.')]:
        after=None;page=0
        while True:
            args=[TOPOLOGY,'query-claims','--input-bundle',base/'topology','--limit','1000']
            if prefix:args += ['--predicate-prefix',prefix]
            if after:args += ['--after',after]
            rc,out=run(label+f'.page-{page:04d}',args,CONSUMER,base/'query-outputs')
            if rc: break
            result=json.loads(out.read_text()); after=result.get('result',result).get('next_after');page+=1
            if not after: break
            if page>1000: raise RuntimeError('Unexpected excessive pagination; preserve existing pages')
    packet=json.loads((base/'repository-model/packet.json').read_text())
    repo_id=packet['payload']['repositories'][0]['repository_id']
    for label,opt in [('generic-impact',[]),('resolution-aware-impact',['--resolution-aware'])]:
        run(label,[TOPOLOGY,'impact','--input-bundle',base/'topology','--entity',repo_id,'--direction','both','--maximum-depth','10',*opt],CONSUMER,base/'impact-outputs')
    run('header-assertion-fidelity',[sys.executable,ROOT/'00_execution_manifest/raw_fidelity.py',base],PRODUCER,logs)
    after=snapshot(source,base/'source-inventory-after')
    assert state==after, 'Read-only observation changed tracked source or git status'
if __name__=='__main__':
    observation(sys.argv[1],Path(sys.argv[2]))
