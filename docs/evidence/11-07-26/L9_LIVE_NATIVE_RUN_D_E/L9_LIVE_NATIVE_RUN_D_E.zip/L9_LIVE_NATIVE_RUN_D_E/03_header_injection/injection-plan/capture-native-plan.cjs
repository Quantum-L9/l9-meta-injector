const fs=require('node:fs');
const producer='/home/ubuntu/live-native-workspace/l9-meta-injector';
const pkg=require(producer);const advanced=require(producer+'/dist/public/advanced.js');
const root='/home/ubuntu/live-native-workspace/l9-cognitive-runtime';
const out='/home/ubuntu/output/L9_LIVE_NATIVE_RUN_D_E/03_header_injection/injection-plan';
const result=pkg.loadRepositoryAuthority(root);if(result.conflicts.length)throw new Error(JSON.stringify(result.conflicts));
const config={root,glob:'**/*',outDir:out,indexDir:out,namespace:'l9-cognitive-runtime',authority:'Quantum-L9',nearDupThreshold:0.9,hashPrefixLength:16,verbose:false,llmEnabled:false,normalizeFilenames:false,writeInjectLog:false,localFiles:false,persistOutputs:false};
advanced.planCarrierOperationAsync({mode:'apply',authority:result.authority,config}).then(plan=>{
fs.writeFileSync(out+'/complete-native-write-plan.json',JSON.stringify(plan,null,2)+'\n');
console.log(JSON.stringify({inline_plans:plan.inlinePlans.length,inline_would_change:plan.inlinePlans.filter(x=>x.wouldChange).length,index_path:'.l9/metadata-index.jsonl',planned_index_hash:plan.metadataIndex.sha256}));
}).catch(e=>{console.error(e.stack);process.exitCode=1;});
