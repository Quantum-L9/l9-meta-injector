# L9 Audit Suite — Findings (no-contract run)

- **Suite:** l9-audit-suite v0.2.0 (consolidated)  |  **finding schema:** v1.0.0
- **Mode:** `--status` + leverage-gate + schema-conformance — **no Flawless-Victory contracts generated** (no `task-*.yaml` emitted)
- **Input report:** `examples/example_findings.json`  |  **base_ref:** `d32e84b`  |  **MSNA:** `AUD-003`
- **Leverage reject threshold:** 2.5
- **Queue order (MSNA → blocks_release → severity):** AUD-003 → AUD-004  |  **next:** AUD-003
- **Schema conformance:** 2/2 valid — _all findings conform to canonical schema_

## Findings (2)

| ID | Severity | Blocks release | Category | Leverage | Gate | Schema |
|---|---|---|---|---|---|---|
| AUD-003 | high | True | duplication | 4.350 | **promote** | valid |
| AUD-004 | low | False | style | 0.450 | **defer** | valid |

## Finding detail

### AUD-003 — high (promote)
- **Rule broken:** duplicated rule-mode resolver script across repos
- **Evidence:** `repoA/scripts/rule_mode.py:12 repoB/scripts/rule_mode.py:9`
- **Impact:** drift across repos, editor bypasses CI
- **Correction:** consolidate into shared module, install as versioned artifact
- **Owner layer:** sdk  |  **blocks_release:** True  |  **cwe:** —
- **Leverage preflight:** {'future_nodes_accelerated': 5, 'existing_nodes_strengthened': 4, 'reusable_primitive_created': 5, 'graphable_outputs': 3, 'maintenance_load_risk': 4}
- **Leverage gate:** leverage_score 4.35 meets threshold → **promote**

### AUD-004 — low (defer)
- **Rule broken:** docstring style inconsistency
- **Evidence:** `repoC/utils/helpers.py:44`
- **Impact:** minor readability
- **Correction:** reformat docstring
- **Owner layer:** sdk  |  **blocks_release:** False  |  **cwe:** —
- **Leverage preflight:** {'future_nodes_accelerated': 0, 'existing_nodes_strengthened': 1, 'reusable_primitive_created': 0, 'graphable_outputs': 0, 'maintenance_load_risk': 2}
- **Leverage gate:** leverage_score 0.45 below reject threshold 2.5 → **defer**

## What 'no-contract' means here

The suite's normal path (`one_command_chain.py` without `--status`, or `audit_to_contract.py`) translates each promoted finding into a **Flawless-Victory task YAML** (`task-<id>.yaml`) plus a follow-up verification stub — those are the *contracts*. This run deliberately used the status/evaluation path only, so the queue, leverage decisions, and schema conformance are computed and reported, but **no contract artifacts were written**. `AUD-003` is queued as `promote` (would become a contract in a normal run); `AUD-004` auto-defers on the leverage gate.

## Files

- `AUDIT_FINDINGS.md` — this report
- `findings.json` — all findings, normalized via the canonical schema, with leverage scores + gate decisions
- `status.json` — queue/status output from `one_command_chain.py --status`
- `leverage-report.json` — per-finding leverage score + promote/defer decision
- `schema-conformance.json` — audit-07 style schema-validation pass over all findings
- `automation_state.json` — orchestrator run state (no completed/blocked/deferred yet)
- `example_findings.json` — the canonical input report the suite consumed
