# Packed Service

> **Status:** deprecated

Replaced by Quantum-L9/successor-service
