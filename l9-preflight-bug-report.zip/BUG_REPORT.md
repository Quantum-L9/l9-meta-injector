# Bug Report — L9 Repository Preflight v4.2

**Component:** `scripts/preflight/forensic/gate20.py` (Gate 20 forensic synthesis)
**Discovered:** during a real filesystem-mode run against `quantum-l9/l9-meta-injector`
**Severity:** Medium (evidence-integrity defect; does **not** flip final pass/fail)
**Status:** Fixed — patch + regression test included in this package
**Verification:** `python -m pytest -q` → **129 passed** with the fix applied

---

## Summary

The Gate 20 deterministic "static" synthesis **double-counts every finding that
originates in an extended gate** (G15–G19, `SEM-ACT-*`, G20). The duplication
propagates into the forensic audit artifacts and into the evidence payload that
is handed to the Gate 20B reasoning model.

## Evidence (observed in generated `gate20-static.json`)

| Field | Emitted (buggy) | Actually unique |
|---|---|---|
| `deterministic_recommendations` | 20 | 8 |
| `unresolved_evidence_gaps` | 6 | 3 |
| `cross_gate_patterns` | 2 | 1 |
| `systemic_risks` | 2 | 1 |

The emitted `gate20-reasoning-request.json` correspondingly listed
`["G18-radon","G18-jscpd","G18-import-linter","G18-radon","G18-jscpd","G18-import-linter"]`
under `evidence_gaps`, and `G16-HEALTH` appeared twice in both
`corroborated_findings` and `systemic_risks`.

## Root cause

`evaluate()` builds `surfaced_findings` from the caller-supplied `all_findings`,
then **appends those same findings a second time** as a synthetic gate on top of
the original `gate_results`, and `_static()` flattens the union without
de-duplication:

```python
# gate20.py — evaluate()
surfaced_findings = list(all_findings or [...])
synthesis_results = list(gate_results)                    # already holds the extended findings
if all_findings is not None:
    synthesis_results.append(
        {"gate_id": 0, "name": "all-surfaced-findings", "findings": surfaced_findings}
    )                                                     # ...appends them AGAIN
static = _static(profile, synthesis_results, evidence)    # flattens both → duplicates
```

```python
# gate20.py — _static()
prior = [finding for gate in gate_results for finding in gate.get("findings", [])]
```

The caller `v39.py:35–36` passes
`all_findings = report findings + extended findings`. The extended findings
therefore live in **both** `gate_results` and the appended synthetic gate, so
every extended finding is counted twice while universal/report-level findings
are counted once.

## Reach

The canonical entry point chains `v42 → v41 → v4 → v39`, and none of the
wrappers re-run Gate 20 — so this affects **every real run**, including the
v4.2 report. It pollutes:

- `forensic_audit.static` (and `gate20-static.json`)
- `gate20-forensic-audit.json`
- `deterministic_summary` and `evidence_gaps` **sent to the reasoning LLM**
  (wasted tokens + biased prompt)

It does **not** change the final result: top-level `findings` and
`preflight_result` are computed on a separate, correct code path (14 unique
findings, no duplicates). The 129-test suite passed before the fix because no
test asserts de-duplication on this path.

## The fix

De-duplicate by finding `id` inside `_static()`. This is the single choke point
every one of the four affected fields flows through, and it is defensive against
*any* caller that passes overlapping evidence.

See `fix-gate20-double-count.patch`. Apply from the repo root:

```bash
git apply fix-gate20-double-count.patch
```

Or, if applying inside the skill directory, strip the leading path prefix:

```bash
git apply -p6 fix-gate20-double-count.patch   # drops .claude/skills/l9-repo-preflight/scripts/preflight/forensic/
```

## Post-fix verification

| Check | Result |
|---|---|
| `python -m pytest -q` | 129 passed |
| `cross_gate_patterns` | 2 → 1 (no dupes) |
| `systemic_risks` | 2 → 1 (no dupes) |
| `unresolved_evidence_gaps` | 6 → 3 (no dupes) |
| `deterministic_recommendations` | one entry per finding (the 6 `SEM-ACT` "pin action" recommendations remain, correctly, one per distinct finding) |

A regression test that fails on the old code and passes on the fixed code is
included as `test_gate20_no_duplicate_synthesis.py`.
