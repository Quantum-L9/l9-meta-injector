# L9 Repository Preflight v4.2 — Bug Report & Improvement Package

Contents:
- `BUG_REPORT.md` — confirmed Gate 20 double-counting bug: evidence, root cause, reach, fix, verification.
- `fix-gate20-double-count.patch` — the fix. Apply from repo root: `git apply fix-gate20-double-count.patch`
- `test_gate20_no_duplicate_synthesis.py` — regression test (fails pre-fix, passes post-fix). Drop into the skill's `tests/`.
- `IMPROVEMENTS.md` — 5 prioritized suggestions for improvement (plus 2 minor notes).

Verification: with the patch applied, `python -m pytest -q` => 129 passed.
