# Suggestions for Improvement — L9 Repository Preflight v4.2

These are observations from installing and running the skill end-to-end. They
are ordered roughly by value-to-effort. None are blocking; #1 is the one most
worth doing alongside the bug fix.

---

## 1. Ship the runtime dependencies the skill actually needs

**Observed:** A fresh run required manually `pip install`-ing `pytest`,
`jsonschema`, and `pyyaml` (the tests and schema validation import them), and
the optional `requirements-tree-sitter.txt` is the only dependency file in the
repo. There is no `requirements.txt` / `pyproject.toml` declaring the core
runtime + test dependencies, so `python -m pytest -q` fails out of the box with
`No module named pytest`.

**Suggestion:** Add a `requirements.txt` (runtime) and
`requirements-dev.txt` (test/lint), or a `pyproject.toml` with `[project]` +
`[project.optional-dependencies]`. This makes the README's "Validate the skill"
block work on first try and lets `full_preflight` reach non-degraded state more
often.

## 2. Give the reasoning-request evidence a canonical, de-duplicated shape

**Observed:** Even setting aside the double-count bug, several synthesis lists
(`deterministic_recommendations`, `evidence_gaps`) carry repeated string values
because they are emitted one-per-finding. The payload handed to the Gate 20B
model therefore contains redundant lines that cost tokens and can bias
weighting toward whatever is repeated most.

**Suggestion:** Emit **grouped** evidence to the model — e.g.
`{"recommendation": "pin_static_github_action", "finding_ids": ["SEM-ACT-1", ...]}`
— so each distinct recommendation/gap appears once with its supporting finding
ids. Determinism is preserved and the prompt gets materially smaller.

## 3. Cover the `v39` → Gate 20 overlap path with a test

**Observed:** The full 129-test suite passed while the synthesis output was
visibly doubled, because no test exercises `evaluate(..., all_findings=...)`
with `all_findings` overlapping `gate_results` — the exact shape the real
pipeline produces.

**Suggestion:** Add the included
`test_gate20_no_duplicate_synthesis.py` (or equivalent) to `tests/`, and more
generally add one integration assertion per pipeline version that the
`forensic_audit.static` projections contain no duplicate finding ids. This
class of "aggregation counted twice" bug is invisible to the current unit
tests.

## 4. Make report size scale-aware (stream / summarize large artifacts)

**Observed:** For this modest repo the single `preflight-report.json` was
**~14 MB** and `semantic-snapshot.json` ~13 MB, because the full semantic
snapshot (every fact) is embedded inline in the top-level report *and* emitted
separately under `--artifact-dir`. On a large repo this becomes unwieldy to
transmit or diff.

**Suggestion:** Keep the top-level report lean — reference the snapshot by
artifact path + digest (as already done for `environment_capability_report_ref`)
rather than inlining `semantic_snapshot`/`semantic_index` payloads. Offer a
`--max-inline-facts` / `--lean` flag that stores heavy evidence only as
sidecar artifacts.

## 5. Reduce version-module sprawl / clarify the canonical surface

**Observed:** The pipeline is a deep wrapper chain
(`v42 → v41 → v4 → v39 → v38 → …`), with `VERSIONS`/`gate20` version strings
duplicated across modules and the SKILL.md pointing at `v41.py` as the "control
plane" while `run_preflight.py` actually imports `v42`. This makes it easy to
fix a bug in one layer and miss that another layer shadows it.

**Suggestion:** Document (or enforce) a single canonical entry module and treat
earlier `vNN.py` files explicitly as frozen compatibility shims — e.g. a short
`ARCHITECTURE.md` mapping the chain, and a test asserting
`run_preflight` imports the highest version. Longer term, collapse the shared
logic (kernel loading, gate registry, synthesis) into named modules instead of
version-numbered ones.

---

### Also worth a glance (minor)
- `references/kernel-runtime.md` and README reference `ci_gate_kernel.v1`
  binding Gate 15↔14; a quick assertion that all four kernels load on a clean
  checkout would catch contract drift early.
- Exit code `1` is returned whenever any blocker finding exists, which is
  correct — but it's worth documenting prominently in the README so CI authors
  don't mistake a successful audit-with-findings for a tool crash.
