"""Regression test for the Gate 20 forensic-synthesis double-counting bug.

Fails on the pre-fix code (extended-gate findings counted twice) and passes
once `_static()` de-duplicates by finding id.

Place this file in `tests/` inside the skill and run with `python -m pytest`.
"""
from __future__ import annotations

from pathlib import Path

from preflight.forensic.gate20 import evaluate


def _finding(fid: str, gate_id: int, status: str, rec: str) -> dict:
    return {
        "id": fid,
        "gate_id": gate_id,
        "status": status,
        "remediation_id_or_recommended_change": rec,
    }


def test_static_synthesis_does_not_double_count_extended_findings() -> None:
    # One extended gate carrying a blocker and a not_observed gap.
    extended = [
        {
            "gate_id": 16,
            "name": "reliability",
            "findings": [_finding("G16-HEALTH", 16, "blocker", "add a health endpoint")],
        },
        {
            "gate_id": 18,
            "name": "quality",
            "findings": [_finding("G18-radon", 18, "not_observed", "provide radon")],
        },
    ]
    # Caller passes the flattened union as all_findings — the same overlap the
    # real v39 pipeline produces.
    surfaced = [f for g in extended for f in g["findings"]]

    result = evaluate(
        Path("."),
        profile={},
        gate_results=extended,
        evidence={"contradictions": [], "complete_tree": True},
        mode="static_only",
        all_findings=surfaced,
    )
    static = result["static"]

    # Each finding must appear exactly once in every synthesis projection.
    patterns = [p["finding_id"] for p in static["cross_gate_patterns"]]
    risks = [r["finding_id"] for r in static["systemic_risks"]]
    gaps = static["unresolved_evidence_gaps"]
    recs = static["deterministic_recommendations"]

    assert patterns == ["G16-HEALTH"], patterns
    assert risks == ["G16-HEALTH"], risks
    assert gaps == ["G18-radon"], gaps
    assert recs.count("add a health endpoint") == 1, recs
    assert recs.count("provide radon") == 1, recs

    # And the reasoning request must not carry duplicated evidence gaps.
    corroborated = static["findings"][0]["evidence"]["corroborated_findings"]
    assert [c["finding_id"] for c in corroborated] == ["G16-HEALTH"], corroborated
